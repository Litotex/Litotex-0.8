<?xml version="1.0"?>
<sql>
<query version="0.1.0">DROP TABLE `lttx_test1`;</query>
<query version="0.2.0">DROP TABLE `lttx_test2`;</query>
<query version="0.3.0">DROP TABLE `lttx_test3`;</query>
<query version="0.4.0">DROP TABLE `lttx_test4`;;</query>
<query version="0.5.0">DROP TABLE `lttx_test5`;</query>
</sql>
