<?php
class installer_login2 extends installer{
	protected function _freeInstall(){}
}
