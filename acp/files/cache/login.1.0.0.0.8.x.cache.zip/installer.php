<?php
class installer_login extends installer{
	protected function _freeInstall(){}
}